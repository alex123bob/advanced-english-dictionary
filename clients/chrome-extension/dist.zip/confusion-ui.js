(function () {
    var posIcons = {
        verb: 'fa-running', noun: 'fa-cube', adjective: 'fa-paint-brush',
        adverb: 'fa-tachometer-alt', preposition: 'fa-arrows-alt',
        conjunction: 'fa-link', interjection: 'fa-comment-dots'
    };

    function escapeHtml(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function enhanceText(value) {
        var safe = escapeHtml(value);
        var mwc = typeof makeWordsClickable === 'function' ? makeWordsClickable : function (t) { return t; };
        return mwc(safe);
    }

    function isZhMode() {
        return document.documentElement.dataset.responseLanguage === 'zh-cn';
    }

    function t(en, zh) {
        return isZhMode() ? zh : en;
    }

    function renderScaffold(searchedWord, confusedWord) {
        var safeSearchedWord = escapeHtml(searchedWord);
        var safeConfusedWord = escapeHtml(confusedWord);
        return '<div class="wcd-b-wrap">' +
            '<div class="wcd-b-toolbar">' +
                '<div class="wcd-b-title">' +
                    '<span class="wcd-b-title-kicker"><i class="fas fa-microscope"></i> ' + t('Word Lab', '词义对比') + '</span>' +
                    '<span class="wcd-b-title-main">' +
                    '<span class="wcd-b-title-word wcd-b-title-word-a">' + safeSearchedWord + '</span>' +
                    '<span class="wcd-b-title-vs">vs</span>' +
                    '<span class="wcd-b-title-word wcd-b-title-word-b">' + safeConfusedWord + '</span>' +
                    '</span>' +
                '</div>' +
                '<div class="wcd-b-export-actions" aria-label="' + t('Export comparison', '导出对比') + '">' +
                    '<button type="button" class="wcd-b-export-btn" data-export-format="pdf" title="' + t('Export as PDF', '导出 PDF') + '" aria-label="' + t('Export comparison as PDF', '导出对比为 PDF') + '" disabled><i class="fas fa-file-pdf"></i></button>' +
                    '<button type="button" class="wcd-b-export-btn" data-export-format="png" title="' + t('Export as PNG', '导出 PNG') + '" aria-label="' + t('Export comparison as PNG', '导出对比为 PNG') + '" disabled><i class="fas fa-file-image"></i></button>' +
                '</div>' +
            '</div>' +
            '<div class="wcd-b-export-status" aria-live="polite"></div>' +
            '<div class="wcd-b-export-surface">' +
            '<div class="wcd-slot-meta"><div class="wcd-skeleton wcd-skeleton-meta"></div></div>' +
            '<div class="wcd-b-cards-row">' +
                '<div class="wcd-slot-card-a"><div class="wcd-skeleton wcd-skeleton-card"></div></div>' +
                '<div class="wcd-b-vs-divider"><div class="wcd-b-vs-badge">VS</div></div>' +
                '<div class="wcd-slot-card-b"><div class="wcd-skeleton wcd-skeleton-card"></div></div>' +
            '</div>' +
            '</div>' +
        '</div>';
    }

    function renderMeta(meta, searchedWord, confusedWord) {
        var confusion_type = meta.confusion_type;
        var quick_rule = meta.quick_rule;
        var key_differentiator = meta.key_differentiator;
        var difficulty = meta.difficulty;

        var difficultyConfig = {
            low:    { color: '#10b981', label: t('Easy to tell apart', '容易区分'), icon: 'fa-check-circle' },
            medium: { color: '#f59e0b', label: t('Often confused', '容易混淆'),     icon: 'fa-exclamation-circle' },
            high:   { color: '#ef4444', label: t('Very easily mixed', '非常容易混淆'),  icon: 'fa-times-circle' }
        };
        var diff = difficultyConfig[difficulty] || { color: '#94a3b8', label: difficulty || t('Unknown', '未知'), icon: 'fa-circle' };

        var typeIcons = {
            near_homophone: 'fa-volume-up', semantic_overlap: 'fa-project-diagram',
            spelling_similarity: 'fa-spell-check', false_friend: 'fa-mask', register_mismatch: 'fa-sliders-h'
        };
        var typeLabels = {
            near_homophone: t('Sounds alike', '发音相近'), semantic_overlap: t('Meaning overlap', '含义重叠'),
            spelling_similarity: t('Similar spelling', '拼写相近'), false_friend: t('False friend', '假朋友词'), register_mismatch: t('Register mismatch', '语体不一致')
        };
        var typeIcon  = typeIcons[confusion_type]  || 'fa-question-circle';
        var typeLabel = typeLabels[confusion_type] || confusion_type;

        var html = '';

        html += '<div class="wcd-b-meta-panel">';
        html += '<div class="wcd-b-tags">' +
            '<span class="wcd-b-type-pill"><i class="fas ' + typeIcon + '"></i> ' + escapeHtml(typeLabel) + '</span>' +
            '<span class="wcd-b-diff-pill" style="background:' + diff.color + '18;color:' + diff.color + ';border-color:' + diff.color + '40">' +
                '<i class="fas ' + diff.icon + '"></i> ' + escapeHtml(diff.label) +
            '</span>' +
        '</div>';

        if (quick_rule) {
            html += '<div class="wcd-b-quick-rule">' +
                '<div class="wcd-b-quick-rule-icon"><i class="fas fa-bolt"></i></div>' +
                '<div class="wcd-b-quick-rule-body">' +
                    '<div class="wcd-b-quick-rule-label">' + t('Rule', '判断规则') + '</div>' +
                    '<div class="wcd-b-quick-rule-text">' + enhanceText(quick_rule) + '</div>' +
                '</div>' +
            '</div>';
        }

        if (key_differentiator) {
            html += '<div class="wcd-b-key-diff">' +
                '<div class="wcd-b-key-diff-icon"><i class="fas fa-not-equal"></i></div>' +
                '<div class="wcd-b-key-diff-body">' +
                    '<div class="wcd-b-key-diff-label">' + t('Difference', '关键区别') + '</div>' +
                    '<div class="wcd-b-key-diff-text">' + enhanceText(key_differentiator) + '</div>' +
                '</div>' +
            '</div>';
        }
        html += '</div>';

        return html;
    }

    function renderCard(profileData, examplesData, wordLabel, side, posMatch) {
        var posHighlight = !posMatch ? 'wcd-b-attr-diff' : 'wcd-b-attr-same';
        var posIcon = posIcons[profileData.part_of_speech] || 'fa-tag';

        var html = '<div class="wcd-b-card wcd-b-card-' + side + '">';

        html += '<div class="wcd-b-card-head">' +
            '<span class="wcd-b-card-marker">' + (side === 'a' ? 'A' : 'B') + '</span>' +
            '<span class="wcd-b-card-word">' + escapeHtml(wordLabel) + '</span>' +
            '<span class="wcd-b-attr-pill ' + posHighlight + '"><i class="fas ' + posIcon + '"></i> ' + escapeHtml(profileData.part_of_speech || 'word') + '</span>' +
        '</div>';

        html += '<div class="wcd-b-card-body">';

        html += '<div class="wcd-b-card-meaning">' +
            '<div class="wcd-b-card-kicker">' + t('Core sense', '核心含义') + '</div>' +
            '<div class="wcd-b-card-meaning-text">' + enhanceText(profileData.core_meaning) + '</div>' +
        '</div>';

        var hasExampleSentence = examplesData && examplesData.example_sentences && examplesData.example_sentences.length;
        var hasUsageNote = examplesData && examplesData.usage_note;
        var hasGrammarNote = profileData.grammar_note;
        var shouldRenderInsightPanel = hasExampleSentence || hasUsageNote || hasGrammarNote || !examplesData;
        var shouldRenderNoteStack = hasUsageNote || hasGrammarNote;

        if (shouldRenderInsightPanel) {
            html += '<div class="wcd-b-insight-panel">';
        }

        if (hasExampleSentence) {
            html += '<div class="wcd-b-card-example">' +
                '<i class="fas fa-quote-left wcd-b-quote-icon"></i>' +
                '<em>' + enhanceText(examplesData.example_sentences[0]) + '</em>' +
            '</div>';
        } else if (!examplesData) {
            html += '<div class="wcd-b-card-example-skeleton wcd-skeleton"></div>';
        }

        if (shouldRenderNoteStack) {
            html += '<div class="wcd-b-note-stack">';
            if (hasUsageNote) {
                html += '<div class="wcd-b-card-note wcd-b-card-usage-note">' +
                    '<div class="wcd-b-note-icon"><i class="fas fa-lightbulb"></i></div>' +
                    '<div class="wcd-b-note-copy">' +
                        '<div class="wcd-b-note-label">' + t('Use when', '使用场景') + '</div>' +
                        '<div class="wcd-b-note-text">' + enhanceText(examplesData.usage_note) + '</div>' +
                    '</div>' +
                '</div>';
            }
            if (hasGrammarNote) {
                html += '<div class="wcd-b-card-note wcd-b-card-grammar">' +
                    '<div class="wcd-b-note-icon"><i class="fas fa-cogs"></i></div>' +
                    '<div class="wcd-b-note-copy">' +
                        '<div class="wcd-b-note-label">' + t('Grammar', '语法') + '</div>' +
                        '<div class="wcd-b-note-text">' + enhanceText(profileData.grammar_note) + '</div>' +
                    '</div>' +
                '</div>';
            }
            html += '</div>';
        }

        if (shouldRenderInsightPanel) {
            html += '</div>';
        }

        if (profileData.collocations && profileData.collocations.length) {
            html += '<div class="wcd-b-card-section">' +
                '<div class="wcd-b-card-section-label"><i class="fas fa-link"></i> ' + t('Explore with', '常见搭配') + '</div>' +
                '<div class="wcd-b-card-chips">' + profileData.collocations.map(function (c) { return '<span class="wcd-b-colloc-chip">' + escapeHtml(c) + '</span>'; }).join('') + '</div>' +
            '</div>';
        }

        html += '</div></div>';
        return html;
    }

    window.ConfusionUI = {
        renderScaffold: renderScaffold,
        renderMeta: renderMeta,
        renderCard: renderCard
    };
})();
